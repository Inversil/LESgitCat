--- === hs.hash ===
---
--- Various hashing algorithms

local hash = require "hs.hash.internal"
return hash
