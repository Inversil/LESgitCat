--- === hs.plist ===
---
--- Read and write Property List files

local USERDATA_TAG = "hs.plist"
local module       = require(USERDATA_TAG..".internal")

-- Return Module Object --------------------------------------------------

return module
