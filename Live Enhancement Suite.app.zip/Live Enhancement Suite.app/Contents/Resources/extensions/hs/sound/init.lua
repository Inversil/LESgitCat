
--- === hs.sound ===
---
--- Load/play/manipulate sound files


local module = require("hs.sound.internal")

-- private variables and methods -----------------------------------------

-- Public interface ------------------------------------------------------

-- Return Module Object --------------------------------------------------

return module

